#include "fileexpo.h"
#include "ui_fileexpo.h"
#include <QMessageBox>

FileExpo::FileExpo(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::FileExpo)
{




 // *****This is the OnCreate section of  Project*****//
      ui->setupUi(this);
      QString sPath = "/home/rahul/usb-mount";
      dirmodel = new QFileSystemModel(this);
      dirmodel ->setFilter(QDir::NoDotAndDotDot | QDir::AllDirs ); // For Showing only directories
      dirmodel ->setRootPath(sPath);
      ui->treeView->setModel(dirmodel);
      ui->treeView->setIconSize(QSize(25,25));
      ui->treeView->setAnimated(true);
      ui->treeView->setAutoExpandDelay(50);
      ui->treeView->setExpandsOnDoubleClick(true);

//********  End of the TreeView Setion ...*****///
//****** Start of List View Stion...***//

     filemodel = new QFileSystemModel(this);
     filemodel ->setFilter(QDir::NoDotAndDotDot | QDir::Files ); // For Showing only file
     filemodel ->setRootPath(sPath);
     ui->listView->setModel(filemodel);

    // for QFileSyatemWatcher ....

}




FileExpo::~FileExpo()
{
    delete ui;
}

void FileExpo::on_treeView_clicked(const QModelIndex &index)
{
      QString sPath = dirmodel->fileInfo(index).absoluteFilePath();   //Genarate a absolute file path.
      ui->listView->setRootIndex(filemodel->setRootPath(sPath));
}



