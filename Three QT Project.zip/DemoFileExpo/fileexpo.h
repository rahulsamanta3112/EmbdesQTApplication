#ifndef FILEEXPO_H
#define FILEEXPO_H

  #include <QMainWindow>
  #include <QFileSystemModel>
  #include<QtCore>
  #include<QtGui>
#include <QFileSystemWatcher>

namespace Ui {
class FileExpo;
}

class FileExpo : public QMainWindow
{
    Q_OBJECT

public:
    explicit FileExpo(QWidget *parent = nullptr);
    ~FileExpo();

private slots:
    void on_treeView_clicked(const QModelIndex &index);

  //  void on_pushButton_clicked();

    //void usbDetected();

private:
    Ui::FileExpo *ui;

    QFileSystemModel *dirmodel;// display the dirctory
    QFileSystemModel *filemodel;// Display File.

  // QFileSystemWatcher *FSwatcher;



};

#endif // FILEEXPO_H
