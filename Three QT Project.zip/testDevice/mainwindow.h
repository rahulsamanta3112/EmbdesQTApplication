#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
     void on_btn_usbMount_clicked();

    void on_btn_Temparatur_clicked();

    void on_btn_storageinfo_clicked();

     int mainPath(int argc, char *argv[]);

     void on_Btn_batteryInfo_clicked();

     void QDBusConnection();

     void on_Btn_mountInfo_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
