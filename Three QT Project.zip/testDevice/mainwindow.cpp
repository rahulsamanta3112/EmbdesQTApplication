#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QProcess>
#include <QStorageInfo>
#include<QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QStandardPaths>

//#include <QDBusConnection>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)

{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btn_usbMount_clicked()
{
    QProcess process;
    process.startDetached("mount");
}

void MainWindow::on_btn_Temparatur_clicked()
{   QString tempGet;
    QProcess getTemp;
    tempGet=getTemp.startDetached("acpi -t");
    ui->label_temp->setText(tempGet);
}
void MainWindow::on_btn_storageinfo_clicked()
{
    QDir dir;
    QString curPath = qApp->applicationDirPath();
    ui->storageInfo->setText(qApp->applicationDirPath());
    QStorageInfo info(curPath);
   // qDebug() << "Name: " << info.name();
   // qDebug() << "Root path: " << info.rootPath();
      qDebug() << "App path : " << qApp->applicationDirPath();
      int mainPath(int argc, char *argv[]);
}

int MainWindow::mainPath(int argc, char *argv[])
  {
           QGuiApplication app(argc, argv);
           QQmlApplicationEngine engine;
           // get the applications dir path and expose it to QML

           QUrl appPath(QString("%1").arg(app.applicationDirPath()));
           //engine.rootContext()->setContextProperty("appPath", appPath);

           // Get the QStandardPaths home location and expose it to QML
           QUrl userPath;
           const QStringList usersLocation = QStandardPaths::standardLocations(QStandardPaths::HomeLocation);
           if (usersLocation.isEmpty())
           userPath = appPath.resolved(QUrl("/home/"));
           else
           userPath = QString("%1").arg(usersLocation.first());
           //engine.rootContext()->setContextProperty("userPath", userPath);

           QUrl imagePath;
           const QStringList picturesLocation = QStandardPaths::standardLocations(QStandardPaths::PicturesLocation);
           if (picturesLocation.isEmpty())
              imagePath = appPath.resolved(QUrl("images"));
           else
              imagePath = QString("%1").arg(picturesLocation.first());
           //  engine.rootContext()->setContextProperty("imagePath", imagePath);

           QUrl videoPath;
           const QStringList moviesLocation = QStandardPaths::standardLocations(QStandardPaths::MoviesLocation);
           if (moviesLocation.isEmpty())
              videoPath = appPath.resolved(QUrl("./"));
           else
              videoPath = QString("%1").arg(moviesLocation.first());
           //  engine.rootContext()->setContextProperty("videoPath", videoPath);
           QUrl homePath;
           const QStringList homesLocation = QStandardPaths::standardLocations(QStandardPaths::HomeLocation);
           if (homesLocation.isEmpty())
              homePath = appPath.resolved(QUrl("/"));
           else
              homePath = QString("%1").arg(homesLocation.first());
           // engine.rootContext()->setContextProperty("homePath", homePath);

           QUrl desktopPath;
           const QStringList desktopsLocation = QStandardPaths::standardLocations(QStandardPaths::DesktopLocation);
           if (desktopsLocation.isEmpty())
              desktopPath = appPath.resolved(QUrl("/"));
           else
              desktopPath = QString("%1").arg(desktopsLocation.first());
           //engine.rootContext()->setContextProperty("desktopPath", desktopPath);
           QUrl docPath;
           const QStringList docsLocation = QStandardPaths::standardLocations(QStandardPaths::DocumentsLocation);
           if (docsLocation.isEmpty())
              docPath = appPath.resolved(QUrl("/"));
           else
              docPath = QString("%1").arg(docsLocation.first());
           //  engine.rootContext()->setContextProperty("docPath", docPath);

           QUrl tempPath;
           const QStringList tempsLocation = QStandardPaths::standardLocations(QStandardPaths::TempLocation);
           if (tempsLocation.isEmpty())
              tempPath = appPath.resolved(QUrl("/"));
           else
              tempPath = QString("%1").arg(tempsLocation.first());
           //engine.rootContext()->setContextProperty("tempPath", tempPath);
           engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
           return app.exec();
 }

void MainWindow::on_Btn_batteryInfo_clicked()
{
     QString Batt_percentage;
     QProcess getBatteryInfo;
     Batt_percentage = getBatteryInfo.startDetached("acpi");
     ui->battey_label->setText(Batt_percentage);
}
void MainWindow::on_Btn_mountInfo_clicked()
{   QProcess getMountInfo;
    getMountInfo.startDetached("df -H");
}
